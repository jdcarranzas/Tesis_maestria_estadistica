install.packages('bvartools')
library(bvartools)

data("e6")

data_sim <- read_xlsx("../../Data/sims.xlsx", sheet = "Hoja3") |> dplyr::select(A, B, C, D)

plot(e6) # Plot the series

data_sim <- data_sim |> ts()

data <- gen_vec(data_sim, p = 2, r = 3,
                iterations = 5000, burnin = 1000)

data <- add_priors(data,
                   coint = list(v_i = 0, p_tau_i = 1),
                   coef = list(v_i = 0, v_i_det = 0),
                   sigma = list(df = 0, scale = .0001))

bvec_est <- draw_posterior(data)

summary(bvec_est)
plot(bvec_est)


#devtools::install_github("KevinKotze/tsm")
#devtools::install_github("cran/fArma")

library(tsm)
require(tidyverse)

set.seed(123)

dates_vec <- seq(as.Date("2011-12-30"), as.Date("2013-11-22"), by="weeks")

data <- tibble(
  date_id = rep(dates_vec, 3), 
  ano = lubridate::year(date_id),
  week = lubridate::week(date_id), 
  channel = c(rep("Channel_1", length(dates_vec)), 
              rep("Channel_2", length(dates_vec)),
              rep("Channel_3", length(dates_vec))),
  clicks = c(arima.sim(model = list(ar = 0.8), n = length(dates_vec)) |> cumsum(), 
             arima.sim(model = list(ar = 0.7), n = length(dates_vec)) |> cumsum(),
             arima.sim(model = list(ar = 0.2), n = length(dates_vec)) |> cumsum()),
  impresiones = clicks + rnorm(length(dates_vec), 0, 2),
  inversion = clicks + rnorm(length(dates_vec), 0, 4), 
  sesiones = clicks + rnorm(length(dates_vec), 0, 8)
)

data <- read_xlsx("../../Documento - Proyecto/4_datos_tesis.xlsx",
                  sheet = "Sheet1") |>
  janitor::clean_names() |>
  group_by(channel) |>
  mutate_if(is.numeric, function(x) scales::rescale(x, to = c(1, 100))) |>
  ungroup()

modelo_vecm_1 <- VECM(data = data |> 
                      filter(channel == "Campaign_1") |> 
                      select(clicks, impresiones, inversion, sesiones), lag = 1, r = 3, include = "none", estim = "ML", LRinclude = "none")
modelo_vecm_2 <- VECM(data = data |> 
                        filter(channel == "Channel_2") |> 
                        select(clicks, impresiones, inversion, sesiones), lag = 1, r = 3, include = "none", estim = "ML", LRinclude = "none")
modelo_vecm_3 <- VECM(data = data |> 
                        filter(channel == "Channel_3") |> 
                        select(clicks, impresiones, inversion, sesiones), lag = 1, r = 3, include = "none", estim = "ML", LRinclude = "none")
modelo_vecm_1


# sim_data <- arima.sim(model = list(ar = 0.8), n = 100)
# 
# 
# rbind(c(-0.2, 0.1,0,0), c(0.2,0.4, 0,0))


# Simulación con matrices de coeficientes ---------------------------------

A = list(matrix(c(0.3, 0.01, 0.5, 0,
             0  , 0.4,  -0.3, 0,
             0.3, 0.2, 0.1, -0.3,
             -0.2, 0.45, -0.2, -0.12), ncol = 4, byrow = T), 
         matrix(c(0.2, 0.04, 0.3, 0.2,
                  0  , 0.1,  -0.3, 0,
                  0.2, 0.5, 0.1, -0.2,
                  -0.4, 0.45, -0.3, -0.12), ncol = 4, byrow = T), 
         matrix(c(0.12, 0.4, 0.1, -0.1,
                  0.4 , 0.1,  0, 0,
                  0.2, -0.3, 0.12, -0.5,
                  -0.1, 0.15, -0.4, -0.2), ncol = 4, byrow = T))
B = cbind(c(-0.1,0.1),c(0.2,-0.3))

varstep <- function(A,B,x,y) {
  e = rnorm(4,0,1)
  A%*%x + e
}

x1 = c(.1,-.1,-0.5, 0.5)
y2 = c(.5,5,-.5, 0.1)
z3 = c(0.1, 0.2, -0.6, 0.2)
w4 = c(0.2, 0.12, -0.16, 0.26)



results = cbind(w4,z3,y2,x1)
for (i in 1:3) {
  for (t in seq(1,100))
  {
    temp <- x1
    x1 <- varstep(A[[i]],B,x1,y2)
    results <- cbind(results, x1)
    y2 <- temp
  }
}


xt = results[1,5:304]
yt = results[2,5:304]
zt = results[3,5:304]
wt = results[4,5:304]

# plot(4:104,xt,type = "line")
# lines(4:104,yt,col="red")
# lines(4:104,zt,col="blue")
# lines(4:104,wt,col="orange")

data_sim <- cbind(xt, yt, zt, wt)

data <- tibble(
  date_id = rep(dates_vec, 3), 
  ano = lubridate::year(date_id),
  week = lubridate::week(date_id), 
  channel = c(rep("Channel_1", length(dates_vec)), 
              rep("Channel_2", length(dates_vec)),
              rep("Channel_3", length(dates_vec))) 
) |> cbind(data_sim) |> 
  group_by(channel) |> 
  mutate(clicks = xt |> cumsum(), 
         impresiones = yt |> cumsum(),
         inversion = zt |> cumsum(),
         sesiones = wt |> cumsum()) |> 
  select(-c(xt, yt, zt, wt)) |> mutate_if(is.numeric, function(x) scales::rescale(x, to = c(1, 100))) |>
  ungroup() |> 
  mutate(channel_id = c(rep("1", length(dates_vec)), 
                        rep("2", length(dates_vec)),
                        rep("3", length(dates_vec))))



library("vars")

modelo<-VAR(ts(data),p=1,type=c("none"))

modelo

library(tsDyn)

modelo_vecm <- VECM(data = data, lag = 1, r = 3, include = "none", estim = "ML", LRinclude = "none")
modelo_vecm


